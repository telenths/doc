package com.appen.kepler.app.common.es.data;


import com.appen.kepler.app.common.es.query.EsQueryTerm;
import com.google.common.collect.Iterables;
import lombok.NoArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.Stats;

import java.util.Collection;

@NoArgsConstructor
public class EsAggResult {

    private SearchResponse searchResponse;

    private Aggregations aggregations;

    private static EsAggResult of(Aggregations aggregations) {
        EsAggResult esAggResult = new EsAggResult();
        esAggResult.aggregations = aggregations;
        return esAggResult;
    }

    public static EsAggTermCountResult buildAggTermCount(Aggregations agg
            , final Collection<EsQueryTerm> fieldWithSize
            , int depth) {
        EsAggTermCountResult esAggResult = new EsAggTermCountResult();
        if (agg == null || fieldWithSize == null) {
            return esAggResult;
        }
        if (depth >= fieldWithSize.size()) {
            return esAggResult;
        }
        String currentTermName = Iterables.get(fieldWithSize, depth).getField();
        Terms terms = agg.get(currentTermName);
        if (terms == null) {
            return esAggResult;
        }
        terms.getBuckets().forEach(
                bucket -> esAggResult.add(
                        currentTermName
                        , bucket.getKeyAsString()
                        , bucket.getDocCount()
                        , EsAggResult.buildAggTermCount(bucket.getAggregations(), fieldWithSize, depth + 1)
                )
        );
        return esAggResult;
    }

    public static EsAggTermStatsResult buildAggTermStats(Aggregations agg
            , final Collection<EsQueryTerm> fieldWithSize
            , int depth
            , Collection<String> statFields) {
        EsAggTermStatsResult esAggResult = new EsAggTermStatsResult();
        if (fieldWithSize == null) {
            return esAggResult;
        }
        if (depth >= fieldWithSize.size()) {
            if (statFields != null && !statFields.isEmpty()) {
                statFields.forEach(f -> esAggResult.add(f, buildStats(agg, f)));
            }
            return esAggResult;
        }
        String currentTermName = Iterables.get(fieldWithSize, depth).getField();
        Terms terms = agg.get(currentTermName);
        if (terms == null) {
            return esAggResult;
        }
        terms.getBuckets().forEach(
                bucket -> esAggResult.add(
                        currentTermName
                        , bucket.getKeyAsString()
                        , bucket.getDocCount()
                        , EsAggResult.buildAggTermStats(bucket.getAggregations(), fieldWithSize, depth + 1, statFields)
                )
        );
        return esAggResult;
    }

    public static EsAggStatsResult buildStats(Aggregations agg, final String aggKey) {
        EsAggStatsResult esAggStatsResult = new EsAggStatsResult();
        if (agg == null || aggKey == null) {
            return esAggStatsResult;
        }
        Stats stats = agg.get(aggKey);
        if (stats == null) {
            return esAggStatsResult;
        }
        esAggStatsResult.setMin(stats.getMin())
                .setCount(stats.getCount())
                .setAvg(stats.getAvg())
                .setMax(stats.getMax())
                .setSum(stats.getSum());
        return esAggStatsResult;
    }

}
