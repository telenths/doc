package com.appen.kepler.app.common.es.data;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class EsAggStatsResult {

    private long count;
    private double min;
    private double max;
    private double avg;
    private double sum;

}
