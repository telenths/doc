package com.appen.kepler.app.common.es.client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.DocWriteRequest;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentHelper;
import org.elasticsearch.common.xcontent.XContentType;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor(staticName = "of")
public class EsIngestClient {

    private final RestHighLevelClient restHighLevelClient;

    private static final int retryLimit = 3;

    public boolean bulk(Collection<? extends DocWriteRequest<?>> docWriteRequests, WriteRequest.RefreshPolicy refreshPolicy) throws Exception {
        if (docWriteRequests == null || docWriteRequests.isEmpty()) {
            return true;
        }

        BulkRequest request = new BulkRequest();
        request.timeout(TimeValue.timeValueSeconds(10));
        request.setRefreshPolicy(refreshPolicy);
        docWriteRequests.forEach(request::add);

        for (int i = 0; i < retryLimit; i++) {
            log.debug("EsIngestClient_Bulk DeleteRequest - {} - {}"
                    , request.numberOfActions()
                    , request.requests().stream()
                            .filter(r -> r instanceof DeleteRequest)
                            .map(r -> (DeleteRequest) r)
                            .map(DeleteRequest::toString)
                            .filter(Objects::nonNull)
                            .collect(Collectors.toList()));
            log.debug("EsIngestClient_Bulk IndexRequest - {} - {}"
                    , request.numberOfActions()
                    , request.requests().stream()
                            .filter(r -> r instanceof IndexRequest)
                            .map(r -> (IndexRequest) r)
                            .map(r -> {
                                try {
                                    String source = XContentHelper.convertToJson(r.source(), false, false, XContentType.JSON);
                                    source = source == null
                                            ? null
                                            : source.length() < 8000
                                            ? source
                                            : source.substring(0, 8000);
                                    return "index {[" + r.index() + "][" + r.id() + "], source[" + source + "]}";
                                } catch (Exception ignored) {
                                }
                                return r.toString();
                            })
                            .filter(Objects::nonNull)
                            .collect(Collectors.toList())
            );
            BulkResponse resp = null;
            try {
                resp = restHighLevelClient.bulk(request, RequestOptions.DEFAULT);
                if (!resp.hasFailures()) {
                    return true;
                }
            } catch (Exception e) {
                log.error("EsIngestClient_Bulk Error - {}", e.getMessage(), e);
                throw e;
            } finally {
                log.debug("EsIngestClient_Bulk Response {} - {} - {} - [{}] - {}"
                        , resp == null
                                ? "null"
                                : resp.hasFailures()
                                ? "fail"
                                : "success"
                        , resp == null
                                ? "null"
                                : resp.getTook()
                        , docWriteRequests.size()
                        , i
                        , resp == null
                                ? "null"
                                : resp.hasFailures()
                                ? resp.buildFailureMessage()
                                : "NoFailure"
                );
            }

            Map<String, DocWriteRequest<?>> mapDelete = docWriteRequests.stream()
                    .filter(d -> d instanceof DeleteRequest)
                    .collect(Collectors.toMap(DocWriteRequest::id, x -> x));
            Map<String, DocWriteRequest<?>> mapIndex = docWriteRequests.stream()
                    .filter(d -> d instanceof IndexRequest)
                    .collect(Collectors.toMap(DocWriteRequest::id, x -> x));
            BulkRequest req = new BulkRequest();
            request.timeout(TimeValue.timeValueSeconds(10));
            request.setRefreshPolicy(refreshPolicy);
            for (BulkItemResponse r : resp) {
                if (r == null) {
                    continue;
                }
                if (r.getResponse() == null) {
                    continue;
                }
                if (r.getResponse().getResult() != DocWriteResponse.Result.NOT_FOUND) {
                    continue;
                }
                if (r.isFailed()) {
                    req.add(mapDelete.get(r.getId()));
                    req.add(mapIndex.get(r.getId()));
                }
            }
            request = req;
        }
        return false;
    }

}
