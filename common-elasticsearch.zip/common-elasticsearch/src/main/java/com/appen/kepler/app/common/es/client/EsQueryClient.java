package com.appen.kepler.app.common.es.client;

import com.appen.kepler.app.common.es.data.*;
import com.appen.kepler.app.common.es.query.EsQueryBuilder;
import com.appen.kepler.app.common.es.query.EsQueryTerm;
import com.appen.kepler.app.common.es.response.EsQueryResponse;
import com.appen.kepler.infra.common.util.JsonConverter;
import com.google.common.collect.Iterables;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.search.*;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.client.indices.GetMappingsRequest;
import org.elasticsearch.client.indices.GetMappingsResponse;
import org.elasticsearch.cluster.metadata.MappingMetadata;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.IndexNotFoundException;
import org.elasticsearch.script.Script;
import org.elasticsearch.search.SearchContextMissingException;
import org.elasticsearch.search.aggregations.*;
import org.elasticsearch.search.aggregations.bucket.MultiBucketsAggregation;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.LongBounds;
import org.elasticsearch.search.aggregations.bucket.histogram.ParsedDateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.Cardinality;
import org.elasticsearch.search.aggregations.pipeline.BucketSelectorPipelineAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Builder(toBuilder = true)
public class EsQueryClient {

    private final RestHighLevelClient restHighLevelClient;

    private final Set<String> indices;

    private Integer pageStart;

    private Integer pageSize;

    private EsQueryBuilder esQueryBuilder;

    private Object[] searchAfter;

    private String scrollId;

    private boolean ignoreUnavailable = true;

    private boolean allowNoIndices = false;


    private SearchSourceBuilder getSearchSourceBuilder() {
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        if (pageStart != null) {
            searchSourceBuilder.from(pageStart);
        }
        if (pageSize != null) {
            searchSourceBuilder.size(pageSize);
        }
        if (esQueryBuilder != null) {
            searchSourceBuilder.fetchSource(
                    esQueryBuilder.getIncludes() == null || esQueryBuilder.getIncludes().isEmpty() ? null : esQueryBuilder.getIncludes().toArray(new String[0]),
                    esQueryBuilder.getExcludes() == null || esQueryBuilder.getExcludes().isEmpty() ? null : esQueryBuilder.getExcludes().toArray(new String[0])
            );
            searchSourceBuilder.query(esQueryBuilder.buildQuery());
            searchSourceBuilder.sort(esQueryBuilder.buildSort(restHighLevelClient, indices));
        }
        if (searchAfter != null && searchAfter.length > 0) {
            searchSourceBuilder.searchAfter(searchAfter);
        }
        return searchSourceBuilder;
    }

    private SearchResponse searchInternal(SearchSourceBuilder searchSourceBuilder, TimeValue scrollTimeToLive) throws IOException {
        String logType = scrollTimeToLive != null
                ? "SCROLL"
                : searchSourceBuilder.aggregations() == null
                ? "SEARCH"
                : "AGGREGATE";
        SearchRequest searchRequest = new SearchRequest(indices.toArray(new String[0]))
                .source(searchSourceBuilder)
                .indicesOptions(IndicesOptions.fromOptions(ignoreUnavailable, allowNoIndices, false, false));
        if (scrollTimeToLive != null) {
            searchRequest.scroll(scrollTimeToLive);
        }
        SearchResponse response = null;
        long start = System.currentTimeMillis();
        try {
            response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        } catch (Exception e) {
            log.error("ES_SEARCH_ERROR {} - {} - {} - {}", logType, e.getMessage(), indices, searchRequest, e);
            if (!(e instanceof IndexNotFoundException)) {
                throw e;
            }
        } finally {
            String aggTypes = "";
            if (searchSourceBuilder.aggregations() != null) {
                aggTypes = searchSourceBuilder.aggregations().getAggregatorFactories().stream()
                        .map(BaseAggregationBuilder::getType)
                        .collect(Collectors.joining(","));
            }
            log.debug("ES_SEARCH {} {} - [{}ms] - {} - {}", logType, aggTypes, System.currentTimeMillis() - start, indices, searchRequest);
            String responseString = response == null ? null : response.toString();
            log.debug("ES_SEARCH_RESPONSE {} {} - {} - {}", logType, aggTypes, indices
                    , responseString == null
                            ? null
                            : responseString.length() <= 32766
                            ? responseString
                            : responseString.substring(0, 32766));
        }
        return response;
    }

    public EsQueryResponse search() throws IOException {
        return EsQueryResponse.of(searchInternal(getSearchSourceBuilder(), null));
    }

    private EsQueryResponse scroll() throws IOException {
        EsQueryResponse esQueryResponse = EsQueryResponse.of(searchInternal(getSearchSourceBuilder(), TimeValue.timeValueMinutes(3)));
        this.scrollId = esQueryResponse.getScrollId();
        return esQueryResponse;
    }

    public EsQueryResponse scrollNext() throws IOException {
        if (scrollId == null) {
            return scroll();
        }
        SearchScrollRequest searchScrollRequest = new SearchScrollRequest(scrollId);
        searchScrollRequest.scroll(TimeValue.timeValueMinutes(3));
        SearchResponse response = null;
        long start = System.currentTimeMillis();
        try {
            response = restHighLevelClient.scroll(searchScrollRequest, RequestOptions.DEFAULT);
        } catch (Exception e) {
            log.error("ES_SEARCH_ERROR {} - {} - {} - {}", "SCROLL_NEXT", e.getMessage(), indices, searchScrollRequest, e);
            if (e instanceof SearchContextMissingException) {
                return scroll();
            }
            if (!(e instanceof IndexNotFoundException)) {
                throw e;
            }
        } finally {
            log.debug("ES_SEARCH {} - [{}ms] - {} - {}", "SCROLL_NEXT", System.currentTimeMillis() - start, indices, searchScrollRequest);
            String responseString = response == null ? null : response.toString();
            log.debug("ES_SEARCH_RESPONSE {} - {} - {}", "SCROLL", indices
                    , responseString == null
                            ? null
                            : responseString.length() <= 32766
                            ? responseString
                            : responseString.substring(0, 32766));
        }
        return EsQueryResponse.of(response);
    }

    public void clearScroll() throws IOException {
        if (scrollId == null) {
            return;
        }
        ClearScrollRequest searchScrollRequest = new ClearScrollRequest();
        searchScrollRequest.setScrollIds(List.of(scrollId));
        ClearScrollResponse response = null;
        long start = System.currentTimeMillis();
        try {
            response = restHighLevelClient.clearScroll(searchScrollRequest, RequestOptions.DEFAULT);
        } catch (Exception e) {
            log.error("ES_SEARCH_ERROR {} - {} - {} - {}", "SCROLL", e.getMessage(), indices, searchScrollRequest, e);
            if (!(e instanceof IndexNotFoundException)) {
                throw e;
            }
        } finally {
            log.debug("ES_SEARCH {} - [{}ms] - {} - {}", "CLEAR_SCROLL", System.currentTimeMillis() - start, indices, searchScrollRequest);
            String responseString = response == null ? null : response.toString();
            log.debug("ES_SEARCH_RESPONSE {} - {} - {}", "SCROLL", indices
                    , responseString == null
                            ? null
                            : responseString.length() <= 32766
                            ? responseString
                            : responseString.substring(0, 32766));
        }
    }

    private TermsAggregationBuilder aggregationBuilder(Iterator<EsQueryTerm> esQueryTermIterator) {
        EsQueryTerm esQueryTerm = esQueryTermIterator.next();
        TermsAggregationBuilder aggregationBuilder = AggregationBuilders.terms(esQueryTerm.getField())
                .field(esQueryTerm.getField())
                .size(esQueryTerm.getSize())
                .order(BucketOrder.count(false));
        if (esQueryTerm.getMinDocCount() != null) {
            aggregationBuilder.minDocCount(esQueryTerm.getMinDocCount());
        }
        if (esQueryTerm.getMissing() != null) {
            aggregationBuilder.missing(esQueryTerm.getMissing());
        }
        if (esQueryTerm.getHavingDocCountGreaterThan() != null && esQueryTerm.getHavingDocCountGreaterThan() > 0) {
            Map<String, String> bucketsPathsMap = new HashMap<>();
            bucketsPathsMap.put("doc_count", "_count");
            Script script = new Script("params.doc_count > " + esQueryTerm.getHavingDocCountGreaterThan());
            BucketSelectorPipelineAggregationBuilder bs = PipelineAggregatorBuilders.bucketSelector("bucket_filter", bucketsPathsMap, script);
            aggregationBuilder.subAggregation(bs);
        }
        if (esQueryTermIterator.hasNext()) {
            aggregationBuilder.subAggregation(
                    aggregationBuilder(esQueryTermIterator)
            );
        }
        return aggregationBuilder;
    }

    public EsAggTermCountResult aggregateToDocCountMap(
            Collection<EsQueryTerm> esQueryTerms
    ) throws IOException {
        SearchResponse searchResponse = searchInternal(
                getSearchSourceBuilder()
                        .aggregation(aggregationBuilder(esQueryTerms.iterator()))
                        .size(0)
                , null);
        if (searchResponse == null) {
            return new EsAggTermCountResult();
        }
        return EsAggResult.buildAggTermCount(searchResponse.getAggregations(), esQueryTerms, 0);
    }

    public EsAggTermStatsResult aggregateToDocStatsMap(
            Collection<EsQueryTerm> esQueryTerms
            , Collection<String> statFields) throws IOException {
        if (CollectionUtils.isEmpty(esQueryTerms)) {
            return new EsAggTermStatsResult();
        }
        TermsAggregationBuilder aggregationBuilder = aggregationBuilder(esQueryTerms.iterator());
        AggregationBuilder firstLeaf = aggregationBuilder;
        while (true) {
            Collection<AggregationBuilder> sub = firstLeaf.getSubAggregations();
            if (sub != null && !sub.isEmpty()) {
                firstLeaf = Iterables.getFirst(sub, null);
            } else {
                break;
            }
        }
        AggregatorFactories.Builder stats = AggregatorFactories.builder();
        if (!CollectionUtils.isEmpty(statFields)) {
            statFields.forEach(
                    f -> stats.addAggregator(AggregationBuilders.stats(f).field(f))
            );
        }
        firstLeaf.subAggregations(stats);
        SearchResponse searchResponse = searchInternal(getSearchSourceBuilder()
                        .aggregation(aggregationBuilder)
                        .size(0)
                , null);
        if (searchResponse == null) {
            return new EsAggTermStatsResult();
        }
        EsAggTermStatsResult result = EsAggResult.buildAggTermStats(searchResponse.getAggregations(), esQueryTerms, 0, statFields);
        log.debug("EsAggTermStatsResult - {}", result);
        return result;
    }

    public EsAggStatsResult aggToStats(String field) throws IOException {
        if (field == null) {
            return new EsAggStatsResult();
        }
        String aggKey = "AGG";
        SearchResponse searchResponse = searchInternal(getSearchSourceBuilder()
                        .aggregation(AggregationBuilders.stats(aggKey).field(field))
                        .size(0)
                , null);
        if (searchResponse == null) {
            return new EsAggStatsResult();
        }
        return EsAggResult.buildStats(searchResponse.getAggregations(), aggKey);
    }

    public EsCardinalityResult aggToCardinality(Collection<String> fields) throws IOException {
        if (CollectionUtils.isEmpty(fields)) {
            return EsCardinalityResult.builder().build();
        }
        SearchSourceBuilder searchSourceBuilder = getSearchSourceBuilder();
        fields.forEach(
                f -> searchSourceBuilder.aggregation(
                        AggregationBuilders.cardinality(f).field(f)
                )
        );
        SearchResponse searchResponse = searchInternal(searchSourceBuilder.size(0), null);
        if (searchResponse == null) {
            return EsCardinalityResult.builder().build();
        }
        Aggregations aggregations = searchResponse.getAggregations();
        EsCardinalityResult.EsCardinalityResultBuilder builder = EsCardinalityResult.builder();
        fields.forEach(
                f -> {
                    Cardinality cardinality = aggregations.get(f);
                    builder.cardinality(f, cardinality.getValue());
                }
        );
        return builder.build();
    }

    public Map<String, Object> getSourceMapping() throws IOException {
        GetMappingsRequest getMappingsRequest = new GetMappingsRequest();
        getMappingsRequest.indicesOptions(IndicesOptions.fromOptions(true, true, false, false));
        getMappingsRequest.indices(indices.toArray(new String[]{}));
        GetMappingsResponse response = null;
        try {
            response = restHighLevelClient.indices().getMapping(getMappingsRequest, RequestOptions.DEFAULT);
        } catch (Exception e) {
            log.error("ES_MAPPING_ERROR - {} - {} - {}", e.getMessage(), indices, getMappingsRequest, e);
            if (!(e instanceof ElasticsearchException)) {
                throw e;
            }
        } finally {
            log.debug("ES_MAPPING - {} - {} - {}", indices, getMappingsRequest, response);
        }
        if (response == null) {
            return null;
        }
        if (response.mappings() == null) {
            return null;
        }
        Map<String, Object> map = new HashMap<>();
        for (String index : indices) {
            MappingMetadata metadata = response.mappings().get(index);
            if (metadata == null) {
                continue;
            }
            map.putAll(metadata.sourceAsMap());
        }
        return map;
    }

    public Long count() throws IOException {
        CountRequest request = new CountRequest();
        request.indices(indices.toArray(new String[]{})).query(esQueryBuilder.buildQuery());
        CountResponse response = null;
        try {
            response = restHighLevelClient.count(request, RequestOptions.DEFAULT);
            return response.getCount();
        } catch (Exception e) {
            log.error("ES_COUNT_ERROR - {} - {} - {}", e.getMessage(), indices, request, e);
            if (!(e instanceof ElasticsearchException)) {
                throw e;
            }
        } finally {
            log.debug("ES_COUNT - {} - {} - {}", indices, JsonConverter.objectToJsonSilent(request), response);
        }
        return null;
    }


    /**
     * return a date based time serial data in format of {"2022-11-11T10:10:10.000Z"：{"job1": "1"}} 1 means the doc count
     */
    public Map<String, Map<String, Long>> aggregateToDocCountMap(
            String DateField
            , String subField
            , String timeZone
            , Integer innerSize
            , String from
            , String to
            , ChronoUnit timeInterval) throws IOException {

        DateHistogramInterval interval;
        switch (timeInterval) {
            case WEEKS: {
                interval = DateHistogramInterval.WEEK;
                break;
            }
            case MONTHS: {
                interval = DateHistogramInterval.MONTH;
                break;
            }
            default: {
                interval = DateHistogramInterval.DAY;
                break;
            }
        }
        String dateAgg = "agg1";
        String termAgg = "agg2";
        DateHistogramAggregationBuilder dateHistogramAggregationBuilder = AggregationBuilders
                .dateHistogram(dateAgg)
                .field(DateField)
                .calendarInterval(interval)
                .extendedBounds(new LongBounds(from, to))
                .timeZone(ZoneId.of(timeZone))
                .subAggregation(
                        AggregationBuilders.terms(termAgg).field(subField).size(innerSize)
                );

        SearchSourceBuilder searchSourceBuilder = getSearchSourceBuilder();
        searchSourceBuilder.aggregation(dateHistogramAggregationBuilder);
        searchSourceBuilder.size(0);

        SearchResponse searchResponse = searchInternal(searchSourceBuilder, null);
        ParsedDateHistogram histogram = searchResponse.getAggregations().get(dateAgg);
        Map<String, Aggregations> dateMap = histogram.getBuckets().stream()
                .collect(
                        Collectors.toMap(MultiBucketsAggregation.Bucket::getKeyAsString, MultiBucketsAggregation.Bucket::getAggregations)
                );

        Map<String, Map<String, Long>> data = new HashMap<>();
        dateMap.forEach((k, v) -> {
            Terms t = v.get(termAgg);
            Map<String, Long> map = new HashMap<>();
            t.getBuckets().forEach(i -> map.put(i.getKeyAsString(), i.getDocCount()));
            data.put(k, map);
        });
        return data;
    }

}
