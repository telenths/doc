package com.appen.kepler.app.common.es.template;

import com.appen.kepler.app.common.es.client.EsQueryClient;
import com.appen.kepler.app.common.es.query.EsQueryBuilder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.function.Supplier;

@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Builder(toBuilder = true)
public class EsCountTemplate {

    private final EsQueryClient esQueryClient;
    private Supplier<Boolean> checkTimeout;

    private Supplier<Boolean> afterEsQuery;

    private EsQueryBuilder esQueryBuilder;


    public long query() throws IOException {
        EsQueryClient.EsQueryClientBuilder esQueryClientBuilder = esQueryClient.toBuilder().esQueryBuilder(esQueryBuilder);

        log.debug("esQueryBuilder - {}", esQueryBuilder);

        return esQueryClientBuilder.build().count();
    }
}
