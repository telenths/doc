package com.appen.kepler.app.common.es.response;

import lombok.RequiredArgsConstructor;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RequiredArgsConstructor(staticName = "of")
public class EsQueryResponse {

    private final SearchResponse esQueryResponse;

    public Long getTotalHits() {
        if (esQueryResponse == null) {
            return null;
        }
        return esQueryResponse.getHits().getTotalHits().value;
    }

    public Long getTotalHits(Long defaultValue) {
        if (esQueryResponse == null) {
            return defaultValue;
        }
        return esQueryResponse.getHits().getTotalHits().value;
    }

    public SearchHit[] getHits() {
        if (esQueryResponse == null) {
            return new SearchHit[]{};
        }
        if (esQueryResponse.getHits() == null) {
            return new SearchHit[]{};
        }
        return esQueryResponse.getHits().getHits();
    }

    public List<SearchHit> getHitsAsList() {
        return List.of(getHits());
    }

    public List<String> getHitsSourceAsString() {
        return Arrays.stream(getHits())
                .map(SearchHit::getSourceAsString)
                .collect(Collectors.toList());
    }

    public List<Map<String, Object>> getHitsSourceAsMap() {
        return Arrays.stream(getHits())
                .map(SearchHit::getSourceAsMap)
                .collect(Collectors.toList());
    }

    public Object[] getLastSortValues() {
        SearchHit[] searchHits = getHits();
        if (searchHits.length <= 0) {
            return new Object[]{};
        }
        return searchHits[searchHits.length - 1].getSortValues();
    }

    public String getScrollId() {
        return esQueryResponse == null
                ? null
                : esQueryResponse.getScrollId();
    }

}
