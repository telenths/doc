package com.appen.kepler.app.common.es.data;

import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.ToString;

import java.util.*;

@ToString
public class EsAggTermCountResult {
    @Getter
    private String term;
    private final List<String> keys = new ArrayList<>();
    private final Map<String, Long> countMap = new HashMap<>();
    private final Map<String, EsAggTermCountResult> termsMap = new HashMap<>();

    public void add(String termName, String termValue, Long count, EsAggTermCountResult esAggTermCountResult) {
        this.term = termName;
        if (count != null) {
            keys.add(termValue);
            countMap.put(termValue, count);
        }
        if (esAggTermCountResult != null) {
            termsMap.put(termValue, esAggTermCountResult);
        }
    }

    public String getLastKey() {
        return keys.isEmpty() ? null : Iterables.getLast(keys);
    }

    public Set<EsAggregationResultEntry<EsAggTermCountResult>> entrySet() {
        Set<EsAggregationResultEntry<EsAggTermCountResult>> entrySet = new HashSet<>();
        for (String key : keys) {
            entrySet.add(new EsAggregationResultEntry<>(key, countMap.get(key), termsMap.get(key)));
        }
        return entrySet;
    }

    public Set<String> keySet() {
        return Sets.newHashSet(keys);
    }

    public Long getCount(String key) {
        return countMap.getOrDefault(key, 0L);
    }

    public int getTotalCount() {
        return countMap.values().stream().mapToInt(Long::intValue).sum();
    }

    public EsAggTermCountResult getAgg(String key) {
        return termsMap.getOrDefault(key, null);
    }

    public int keySize() {
        return keys.size();
    }


}
