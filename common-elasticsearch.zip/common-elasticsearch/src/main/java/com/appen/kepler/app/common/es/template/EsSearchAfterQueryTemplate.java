package com.appen.kepler.app.common.es.template;

import com.appen.kepler.app.common.es.client.EsQueryClient;
import com.appen.kepler.app.common.es.query.EsQueryBuilder;
import com.appen.kepler.app.common.es.response.EsQueryResponse;
import com.appen.kepler.infra.common.exception.KeplerException;
import com.appen.kepler.infra.common.util.JsonConverter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.util.Arrays;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Template class for process elasticsearch query
 */
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Builder(toBuilder = true)
public class EsSearchAfterQueryTemplate {

    private static final String REDIS_KEY_PREFIX = "SEARCH_AFTER_KEYWORD_";

    private final EsQueryClient esQueryClient;
    private final RedisTemplate<String, String> stringRedisTemplate;
    private String externalId;
    private Integer pageSize;
    private Supplier<Boolean> checkTimeout;
    private Consumer<EsQueryResponse> onEachEsBatchQueryResult;

    private Supplier<Boolean> afterEsQuery;

    private EsQueryBuilder esQueryBuilder;

    public void query() throws Exception {

        if (onEachEsBatchQueryResult == null) {
            return;
        }

        EsQueryClient.EsQueryClientBuilder esQueryClientBuilder = esQueryClient.toBuilder()
                .pageSize(pageSize != null ? pageSize : 100)
                .esQueryBuilder(esQueryBuilder);

        log.debug(" esQueryBuilder - {}", esQueryBuilder);

        String redisKey = REDIS_KEY_PREFIX + externalId;
        String searchAfterStr = stringRedisTemplate.opsForValue().get(redisKey);
        if (!StringUtils.isEmpty(searchAfterStr)) {
            esQueryClientBuilder.searchAfter(JsonConverter.jsonToObject(searchAfterStr, String[].class));
        }
        log.info("process es query, external id:{}, search after:{} - {}", externalId, searchAfterStr, redisKey);

        EsQueryResponse esQueryResponse = esQueryClientBuilder.build().search();

        while (esQueryResponse != null && esQueryResponse.getHits().length > 0) {
            if (checkTimeout != null && checkTimeout.get()) {
                throw new KeplerException();
            }

            log.info("process es query, external id:{}, results size:{}", externalId, esQueryResponse.getHitsAsList().size());
            onEachEsBatchQueryResult.accept(esQueryResponse);

            // save the search_after keywords
            Object[] searchAfter = esQueryResponse.getLastSortValues();
            if (Arrays.isNullOrEmpty(searchAfter)) {
                log.debug("No searchAfter - {} - {}", externalId, esQueryBuilder);
                break;
            }
            stringRedisTemplate.opsForValue().set(redisKey, JsonConverter.objectToJson(searchAfter), 86400, TimeUnit.SECONDS);

            esQueryResponse = esQueryClientBuilder
                    .searchAfter(searchAfter)
                    .build()
                    .search();
        }
        log.debug("finish es query, external:{}", externalId);

        if (afterEsQuery != null) {
            afterEsQuery.get();
        }

        stringRedisTemplate.delete(redisKey);
    }

}
