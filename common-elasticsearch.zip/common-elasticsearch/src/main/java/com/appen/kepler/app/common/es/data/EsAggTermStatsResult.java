package com.appen.kepler.app.common.es.data;

import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.ToString;

import java.util.*;

@ToString
public class EsAggTermStatsResult {
    @Getter
    private String term;
    private final List<String> keys = new ArrayList<>();
    private final Map<String, Long> countMap = new HashMap<>();
    private final Map<String, EsAggTermStatsResult> termsMap = new HashMap<>();
    private final Map<String, EsAggStatsResult> statsMap = new HashMap<>();

    public Map<String, EsAggStatsResult> getStatsMap() {
        return statsMap;
    }

    public void add(String key, EsAggStatsResult esAggStatsResult) {
        statsMap.put(key, esAggStatsResult);
    }

    public void add(String termName, String termValue, Long count, EsAggTermStatsResult esAggTermCountResult) {
        this.term = termName;
        if (count != null) {
            keys.add(termValue);
            countMap.put(termValue, count);
        }
        if (esAggTermCountResult != null) {
            termsMap.put(termValue, esAggTermCountResult);
        }
    }

    public Set<EsAggregationResultEntry<EsAggTermStatsResult>> entrySet() {
        Set<EsAggregationResultEntry<EsAggTermStatsResult>> entrySet = new HashSet<>();
        for (String key : keys) {
            entrySet.add(new EsAggregationResultEntry<>(key, countMap.get(key), termsMap.get(key)));
        }
        return entrySet;
    }

    public Set<String> keySet() {
        return Sets.newHashSet(keys);
    }

    public Long getCount(String key) {
        return countMap.getOrDefault(key, 0L);
    }

    public EsAggTermStatsResult getAgg(String key) {
        return termsMap.getOrDefault(key, null);
    }

    public int keySize() {
        return keys.size();
    }


}
