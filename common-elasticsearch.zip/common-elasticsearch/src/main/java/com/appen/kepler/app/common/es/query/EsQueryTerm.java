package com.appen.kepler.app.common.es.query;

import lombok.Data;
import lombok.experimental.Accessors;

@Data(staticConstructor = "of")
@Accessors(chain = true)
public class EsQueryTerm {

    private final String field;
    private Integer size = 100;
    private Integer havingDocCountGreaterThan;
    private String missing;
    private Long minDocCount;

}
