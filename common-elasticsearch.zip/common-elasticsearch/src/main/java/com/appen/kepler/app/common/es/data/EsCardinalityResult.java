package com.appen.kepler.app.common.es.data;

import lombok.Builder;
import lombok.Data;
import lombok.Singular;

import java.util.Collections;
import java.util.Map;
import java.util.Set;


@Data
@Builder
public class EsCardinalityResult {

    @Singular
    private Map<String, Long> cardinalities;

    public Set<String> keySet() {
        return cardinalities == null
                ? Collections.emptySet()
                : cardinalities.keySet();
    }

    public long get(String key) {
        if (cardinalities == null) {
            return 0L;
        }
        return cardinalities.getOrDefault(key, 0L);
    }

}
