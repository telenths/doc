package com.appen.kepler.app.common.es.data;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class EsAggregationResultEntry<EsAggregationResult> {
    private String key;
    private Long count;
    private EsAggregationResult esAggregationResult;
}