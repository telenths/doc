package com.appen.kepler.app.common.es.query;

import com.appen.kepler.app.common.aggrid.filter.*;
import com.appen.kepler.app.common.aggrid.request.SortModel;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetFieldMappingsRequest;
import org.elasticsearch.client.indices.GetFieldMappingsResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.appen.kepler.app.common.aggrid.filter.ColumnFilter.Options.*;

@Data
@Slf4j
@RequiredArgsConstructor(staticName = "of")
public class EsQueryBuilder {

    private static final String START_TIME_OF_DAY = " 00:00:00";
    private static final String END_TIME_OF_DAY = " 23:59:59";
    private static final String WHITE_SPACE = " ";

    private static final String ES_ZONED_TIME_REGEX = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z";

    private static final String ES_ZONED_TIME_WITH_MILLIS_REGEX = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}?\\.\\d{3}Z";

    private String queryTextPostFix = "";

    private String sortTextPostFix = null;

    private Map<String, ColumnFilter> filterModel;

    private List<SortModel> sortModels;

    private String queryString;

    private Set<String> includes;
    private Set<String> excludes;

    private boolean isQueryWithLowerCase() {
        return ".lowercase".equalsIgnoreCase(queryTextPostFix);
    }

    public EsQueryBuilder filterModel(Map<String, ColumnFilter> filterModel) {
        this.filterModel = filterModel;
        return this;
    }

    public EsQueryBuilder queryString(String queryString) {
        this.queryString = queryString;
        return this;
    }

    public EsQueryBuilder sortModels(List<SortModel> sortModels) {
        this.sortModels = sortModels;
        return this;
    }

    public EsQueryBuilder queryWithLowerCase() {
        queryTextPostFix = ".lowercase";
        return this;
    }

    public EsQueryBuilder sortWithKeyword() {
        sortTextPostFix = ".keyword";
        return this;
    }

    public EsQueryBuilder includes(Set<String> s) {
        includes = s;
        return this;
    }

    public EsQueryBuilder excludes(Set<String> s) {
        excludes = s;
        return this;
    }

    public List<SortBuilder<?>> buildSort(RestHighLevelClient client, Set<String> indices) {
        if (sortModels == null || sortModels.isEmpty()) {
            return Collections.emptyList();
        }
        List<SortBuilder<?>> sort = buildSort(client, indices, sortModels);
        log.debug("BUILD_SORT - {}", sort);
        return sort;
    }

    private List<SortBuilder<?>> buildSort(RestHighLevelClient client, Set<String> indices, List<SortModel> sortModels) {
        if (CollectionUtils.isEmpty(sortModels)) {
            return null;
        }
        Set<String> fieldSetToCheck = sortModels.stream()
                .map(sortModel -> sortModel.getColId(sortTextPostFix))
                .collect(Collectors.toSet());
        GetFieldMappingsRequest request = new GetFieldMappingsRequest();
        request.indices(indices.toArray(new String[]{}));
        request.fields(String.join(",", fieldSetToCheck));
        try {
            GetFieldMappingsResponse response = client.indices().getFieldMapping(request, RequestOptions.DEFAULT);
            Set<String> fieldsInMapping = response.mappings()
                    .values()
                    .stream()
                    .map(Map::entrySet)
                    .flatMap(Collection::stream)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toSet());
            return sortModels.stream()
                    .map(sortModel -> {
                                SortOrder sortOrder = sortModel.getSort().equalsIgnoreCase(SortModel.ASC)
                                        ? SortOrder.ASC
                                        : SortOrder.DESC;
                                String sortKey = fieldsInMapping.contains(sortModel.getColId(sortTextPostFix))
                                        ? sortModel.getColId(sortTextPostFix)
                                        : sortModel.getColId();
                                return new FieldSortBuilder(sortKey).order(sortOrder);
                            }
                    )
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Error Build Sort - {} - {} ", indices, sortModels, e);
        }
        return null;
    }

    public QueryBuilder buildQuery() {
        if ((filterModel == null || filterModel.isEmpty()) && queryString == null) {
            return QueryBuilders.matchAllQuery();
        }
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (queryString != null && !queryString.isBlank()) {
            boolQueryBuilder.must(QueryBuilders.queryStringQuery(queryString));
        }
        if (filterModel != null && !filterModel.isEmpty()) {
            for (Map.Entry<String, ColumnFilter> entry : filterModel.entrySet()) {
                if (entry.getValue() instanceof NumberColumnFilter) {
                    NumberColumnFilter filter = (NumberColumnFilter) entry.getValue();
                    mustWithExist(boolQueryBuilder, buildQuery(entry.getKey(), filter.getType(), filter.getFilter(), filter.getFilterTo()), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(entry.getKey(), filter.getType(), filter.getFilter(), filter.getFilterTo()), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getType());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getType());
                }
                if (entry.getValue() instanceof DateColumnFilter) {
                    DateColumnFilter filter = (DateColumnFilter) entry.getValue();
                    DateColumnFilter newFilter = processDateFilter(filter.getType(), filter.getFilterType(), filter.getDateFrom(), filter.getDateTo());
                    String from = newFilter.getDateFrom();
                    String to = newFilter.getDateTo();
                    mustWithExist(boolQueryBuilder, buildQuery(entry.getKey(), newFilter.getType(), switchToEsDate(from), switchToEsDate(to)), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(entry.getKey(), newFilter.getType(), switchToEsDate(from), switchToEsDate(to)), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getType());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getType());
                }
                if (entry.getValue() instanceof TextColumnFilter) {
                    TextColumnFilter filter = (TextColumnFilter) entry.getValue();

                    String key = entry.getKey().endsWith(queryTextPostFix)
                            ? entry.getKey()
                            : entry.getKey() + queryTextPostFix;

                    mustWithExist(boolQueryBuilder, buildQuery(key, filter.getType(), filter.getFilter(), null), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(key, filter.getType(), filter.getFilter(), null), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getType());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getType());
                }
                if (entry.getValue() instanceof SetColumnFilter) {
                    SetColumnFilter filter = (SetColumnFilter) entry.getValue();
                    if (filter.getValues() != null && !filter.getValues().isEmpty()) {
                        BoolQueryBuilder or = QueryBuilders.boolQuery();
                        for (String value : filter.getValues()) {
                            if (value == null || value.trim().equalsIgnoreCase("")) {
                                or.should(QueryBuilders.boolQuery().mustNot(QueryBuilders.existsQuery(entry.getKey())));
                                continue;
                            }

                            String key = entry.getKey().endsWith(queryTextPostFix)
                                    ? entry.getKey()
                                    : entry.getKey() + queryTextPostFix;
                            or.should(QueryBuilders.matchQuery(key, value));
                        }
                        boolQueryBuilder.must(or);
                    }
                }


                // =====================================================================

                if (entry.getValue() instanceof NumberColumnFilter2) {
                    NumberColumnFilter2 filter = (NumberColumnFilter2) entry.getValue();
                    Object value1 = filter.getValues() == null
                            ? null
                            : filter.getValues().length == 0
                            ? null
                            : filter.getValues()[0];
                    Object value2 = filter.getValues() == null
                            ? null
                            : filter.getValues().length <= 1
                            ? null
                            : filter.getValues()[1];
                    mustWithExist(boolQueryBuilder, buildQuery(entry.getKey(), filter.getCriteria(), value1, value2), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(entry.getKey(), filter.getCriteria(), value1, value2), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                }
                if (entry.getValue() instanceof DateColumnFilter2) {
                    DateColumnFilter2 filter = (DateColumnFilter2) entry.getValue();
                    String value1 = filter.getValues() == null
                            ? null
                            : filter.getValues().length == 0
                            ? null
                            : filter.getValues()[0];
                    String value2 = filter.getValues() == null
                            ? null
                            : filter.getValues().length <= 1
                            ? null
                            : filter.getValues()[1];

                    DateColumnFilter2 newFilter = processDateFilter2(filter.getCriteria(), filter.getFilterType(), value1, value2);

                    String from = newFilter.getDateFrom();
                    String to = newFilter.getDateTo();
                    mustWithExist(boolQueryBuilder, buildQuery(entry.getKey(), newFilter.getCriteria(), switchToEsDate(from), switchToEsDate(to)), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(entry.getKey(), newFilter.getCriteria(), switchToEsDate(from), switchToEsDate(to)), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                }
                if (entry.getValue() instanceof TextColumnFilter2) {
                    TextColumnFilter2 filter = (TextColumnFilter2) entry.getValue();
                    Object value1 = filter.getValues() == null
                            ? null
                            : filter.getValues().length == 0
                            ? null
                            : filter.getValues()[0];
                    Object value2 = filter.getValues() == null
                            ? null
                            : filter.getValues().length <= 1
                            ? null
                            : filter.getValues()[1];

                    String key = entry.getKey().endsWith(queryTextPostFix)
                            ? entry.getKey()
                            : entry.getKey() + queryTextPostFix;

                    mustWithExist(boolQueryBuilder, buildQuery(key, filter.getCriteria(), value1, value2), entry.getKey());
                    mustNotWithExit(boolQueryBuilder, buildNegativeQuery(key, filter.getCriteria(), value1, value2), entry.getKey());
                    mustExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                    mustNotExit(boolQueryBuilder, entry.getKey(), filter.getCriteria());
                }
                if (entry.getValue() instanceof SetColumnFilter2) {
                    SetColumnFilter2 filter = (SetColumnFilter2) entry.getValue();
                    String key = entry.getKey().endsWith(queryTextPostFix)
                            ? entry.getKey()
                            : entry.getKey() + queryTextPostFix;

                    if (filter.getValues() != null && filter.getValues().length > 0) {
                        if (ColumnFilter.Options.IN.equals(filter.getCriteria())) {
                            BoolQueryBuilder bool = QueryBuilders.boolQuery();
                            for (String value : filter.getValues()) {
                                if (value == null || value.trim().equalsIgnoreCase("")) {
                                    bool.should(QueryBuilders.boolQuery().mustNot(QueryBuilders.existsQuery(entry.getKey())));
                                    continue;
                                }
                                bool.should(QueryBuilders.matchQuery(key, value));
                            }
                            boolQueryBuilder.must(bool);
                        }
                        if (ColumnFilter.Options.NOT_IN.equals(filter.getCriteria())) {
                            boolQueryBuilder.must(QueryBuilders.existsQuery(entry.getKey()));
                            for (String value : filter.getValues()) {
                                if (value.equalsIgnoreCase("")) {
                                    continue;
                                }
                                boolQueryBuilder.mustNot(QueryBuilders.matchQuery(key, value));
                            }
                        }
                    } else {
                        boolQueryBuilder.mustNot(QueryBuilders.existsQuery(entry.getKey()));
                    }
                }
            }
        }
        log.debug("ES_BUILD_QUERY, build query - {} - {}", filterModel, boolQueryBuilder);
        return boolQueryBuilder;
    }

    private String switchToEsDate(String dateString) {
        if (dateString == null) {
            return null;
        }
        if (!dateString.contains(WHITE_SPACE)) {
            return null;
        }
//      "yyyy-MM-dd HH:mm:ss" -> "yyyy-MM-ddTHH:mm:ss.SSSZ"
        dateString = dateString.replaceAll(WHITE_SPACE, "T");
        return dateString + ".000Z";
    }

    private String unifyDateFormat(String input) {
        if (input == null) {
            return null;
        }
        Pattern zonePattern = Pattern.compile(ES_ZONED_TIME_REGEX);
        Matcher result = zonePattern.matcher(input);
        if (result.matches()) {
            return input.substring(0, input.length() - 1).replaceAll("T", WHITE_SPACE);
        }
        Pattern millisPattern = Pattern.compile(ES_ZONED_TIME_WITH_MILLIS_REGEX);
        result = millisPattern.matcher(input);
        if (result.matches()) {
            return input.substring(0, input.length() - 5).replaceAll("T", WHITE_SPACE);
        }
        return input;
    }


    private DateColumnFilter2 processDateFilter2(String criteria, String type, String dateFrom, String dateTo) {
//        String criteria = filter.getType();
//        String type = filter.getFilterType();
//        String dateFrom = unifyDateFormat(filter.getDateFrom());
//        String dateTo = unifyDateFormat(filter.getDateTo());

        dateFrom = unifyDateFormat(dateFrom);
        dateTo = unifyDateFormat(dateTo);

        DateColumnFilter2 newFilter = new DateColumnFilter2();
        newFilter.setCriteria(criteria);
        newFilter.setFilterType(type);
        newFilter.setValues(new String[]{dateFrom, dateTo});

        switch (criteria) {
            case EQUALS: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setCriteria(IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                        newFilter.setDateTo(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                        newFilter.setDateTo(dateFrom);
                    }
                }
                break;
            }
            case NOT_EQUAL: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setCriteria(NOT_IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                        newFilter.setDateTo(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                        newFilter.setDateTo(dateFrom);
                    }
                }
                break;
            }
            case GREATER_THAN: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setCriteria(GREATER_THAN);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                break;
            }
            case IN_RANGE: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setCriteria(IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                if (StringUtils.isNotBlank(dateTo)) {
                    if (!dateTo.contains(WHITE_SPACE)) {
                        newFilter.setDateTo(dateTo + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateTo(dateTo);
                    }
                }
                break;
            }
            default: {
                newFilter.setCriteria(criteria);
                newFilter.setFilterType(type);
                newFilter.setDateFrom(dateFrom);
                newFilter.setDateTo(dateTo);
                if (StringUtils.isNotBlank(dateFrom)) {
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                if (StringUtils.isNotBlank(dateTo) && !dateTo.contains(WHITE_SPACE)) {
                    if (!dateTo.contains(WHITE_SPACE)) {
                        newFilter.setDateTo(dateTo + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateTo(dateTo);
                    }
                }
                break;
            }
        }
        return newFilter;
    }


    //    private DateColumnFilter processDateFilter(DateColumnFilter filter) {
    private DateColumnFilter processDateFilter(String criteria, String type, String dateFrom, String dateTo) {
//        String criteria = filter.getType();
//        String type = filter.getFilterType();
//        String dateFrom = unifyDateFormat(filter.getDateFrom());
//        String dateTo = unifyDateFormat(filter.getDateTo());

        dateFrom = unifyDateFormat(dateFrom);
        dateTo = unifyDateFormat(dateTo);

        DateColumnFilter newFilter = new DateColumnFilter();
        newFilter.setType(criteria);
        newFilter.setFilterType(type);
        newFilter.setDateFrom(dateFrom);
        newFilter.setDateTo(dateTo);

        switch (criteria) {
            case EQUALS: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setType(IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                        newFilter.setDateTo(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                        newFilter.setDateTo(dateFrom);
                    }
                }
                break;
            }
            case NOT_EQUAL: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setType(NOT_IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                        newFilter.setDateTo(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                        newFilter.setDateTo(dateFrom);
                    }
                }
                break;
            }
            case GREATER_THAN: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setType(GREATER_THAN);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                break;
            }
            case IN_RANGE: {
                if (StringUtils.isNotBlank(dateFrom)) {
                    newFilter.setType(IN_RANGE);
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                if (StringUtils.isNotBlank(dateTo)) {
                    if (!dateTo.contains(WHITE_SPACE)) {
                        newFilter.setDateTo(dateTo + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateTo(dateTo);
                    }
                }
                break;
            }
            default: {
                newFilter.setType(criteria);
                newFilter.setFilterType(type);
                newFilter.setDateFrom(dateFrom);
                newFilter.setDateTo(dateTo);
                if (StringUtils.isNotBlank(dateFrom)) {
                    if (!dateFrom.contains(WHITE_SPACE)) {
                        newFilter.setDateFrom(dateFrom + START_TIME_OF_DAY);
                    } else {
                        newFilter.setDateFrom(dateFrom);
                    }
                }
                if (StringUtils.isNotBlank(dateTo) && !dateTo.contains(WHITE_SPACE)) {
                    if (!dateTo.contains(WHITE_SPACE)) {
                        newFilter.setDateTo(dateTo + END_TIME_OF_DAY);
                    } else {
                        newFilter.setDateTo(dateTo);
                    }
                }
                break;
            }
        }
        return newFilter;
    }

    private void mustExit(BoolQueryBuilder boolQueryBuilder, String fieldName, String type) {
        if (fieldName != null && NOT_BLANK.equalsIgnoreCase(type)) {
            boolQueryBuilder.must(QueryBuilders.existsQuery(fieldName));
        }
    }

    private void mustNotExit(BoolQueryBuilder boolQueryBuilder, String fieldName, String type) {
        if (fieldName != null && BLANK.equalsIgnoreCase(type)) {
            boolQueryBuilder.mustNot(QueryBuilders.existsQuery(fieldName));
        }
    }

    private void mustWithExist(BoolQueryBuilder boolQueryBuilder, QueryBuilder queryBuilder, String fieldName) {
        if (queryBuilder != null) {
            boolQueryBuilder.must(QueryBuilders.existsQuery(fieldName));
            boolQueryBuilder.must(queryBuilder);
        }
    }

    private void mustNotWithExit(BoolQueryBuilder boolQueryBuilder, QueryBuilder queryBuilder, String fieldName) {
        if (queryBuilder != null) {
            boolQueryBuilder.must(
                    QueryBuilders.boolQuery()
                            .should(QueryBuilders.boolQuery()
                                    .must(QueryBuilders.existsQuery(fieldName))
                                    .mustNot(queryBuilder))
                            .should(QueryBuilders.boolQuery()
                                    .mustNot(QueryBuilders.existsQuery(fieldName)))
            );
        }
    }

    private QueryBuilder buildQuery(String key, String type, Object filterValue, Object filterValue2) {
        if (type.equalsIgnoreCase(EMPTY)) {
            return null;
        }
        if (key == null) {
            return null;
        }

        switch (type) {
            case EQUALS:
                return filterValue == null ? null : QueryBuilders.matchQuery(key, filterValue);
            case LESS_THAN:
                return filterValue == null ? null : QueryBuilders.rangeQuery(key).lt(filterValue);
            case LESS_THAN_OR_EQUAL:
                return filterValue == null ? null : QueryBuilders.rangeQuery(key).lte(filterValue);
            case GREATER_THAN:
                return filterValue == null ? null : QueryBuilders.rangeQuery(key).gt(filterValue);
            case GREATER_THAN_OR_EQUAL:
                return filterValue == null ? null : QueryBuilders.rangeQuery(key).gte(filterValue);
            case IN_RANGE:
                return filterValue == null ? null
                        : filterValue2 == null ? null
                        : QueryBuilders.rangeQuery(key).from(filterValue, true).to(filterValue2, true);
//            case NOT_BLANK:
//                return QueryBuilders.existsQuery(key);
            case STARTS_WITH:
                return filterValue == null ? null : QueryBuilders.prefixQuery(key,
                        isQueryWithLowerCase() ?
                                filterValue.toString().toLowerCase()
                                : filterValue.toString()
                ).caseInsensitive(true);
            case ENDS_WITH:
                return filterValue == null ? null : QueryBuilders.regexpQuery(key, ".*" + escapeForRegex(
                        isQueryWithLowerCase() ?
                                filterValue.toString().toLowerCase()
                                : filterValue.toString()
                )).caseInsensitive(true);
            case CONTAINS:
                return filterValue == null ? null : QueryBuilders.regexpQuery(key, ".*" + escapeForRegex(
                        isQueryWithLowerCase() ?
                                filterValue.toString().toLowerCase()
                                : filterValue.toString()
                ) + ".*").caseInsensitive(true);
            case REGEX:
                return filterValue == null ? null : QueryBuilders.regexpQuery(key,
                        isQueryWithLowerCase() ?
                                filterValue.toString().toLowerCase()
                                : filterValue.toString()
                ).caseInsensitive(true);
        }
        return null;
    }

    private QueryBuilder buildNegativeQuery(String key, String type, Object filterValue, Object filterValue2) {
        if (type.equalsIgnoreCase(EMPTY))
            return null;

        switch (type) {
            case NOT_EQUAL:
                return filterValue == null ? null : QueryBuilders.matchQuery(key, filterValue);
//            case BLANK:
//                return QueryBuilders.existsQuery(key);
            case NOT_CONTAINS:
                return filterValue == null ? null : QueryBuilders.regexpQuery(key, ".*" + escapeForRegex(filterValue) + ".*").caseInsensitive(true);
            case NOT_IN_RANGE:
                return filterValue == null ? null
                        : filterValue2 == null ? null
                        : QueryBuilders.rangeQuery(key).from(filterValue, true).to(filterValue2, true);
        }
        return null;
    }

    private String escapeForRegex(Object filterValue) {
        if (filterValue == null) {
            return null;
        }
        String REGEX = "[\\[\\]+:{}^~?\\\\/()><=\"!]";
        return RegExUtils.replaceAll(filterValue.toString(), REGEX, "\\\\$0");
    }

}
